package raf.rs.prviprojekatmobilne.calendarRecycler;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;


import java.util.function.Function;

import raf.rs.prviprojekatmobilne.R;
import raf.rs.prviprojekatmobilne.fragments.CalendarFragment;
import raf.rs.prviprojekatmobilne.model.Dan;
import raf.rs.prviprojekatmobilne.model.DanPrioritet;

public class CalendarAdapter extends ListAdapter<Dan, CalendarAdapter.ViewHolder> {

    private CalendarFragment calendarFragment;
    private final Function<Dan, Void> onItemClicked;

    public CalendarAdapter(@NonNull DiffUtil.ItemCallback<Dan> diffCallback, Function<Dan, Void> onItemClicked) {
        super(diffCallback);
        this.onItemClicked = onItemClicked;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.calendar_item, parent, false);

        return new ViewHolder(view, view.getContext(), position -> {
            Dan day = getItem(position);
            onItemClicked.apply(day);
            return null;
        });
    }

    // mesec + godina na vrhu
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Dan day = getItem(position);

        if (day.getDan() == 29 || day.getDan() == 30 || day.getDan() == 31) {
            StringBuilder sb = new StringBuilder();

            switch (day.getMesec()) {
                case 1:
                    sb.append("Januar ");
                    break;
                case 2:
                    sb.append("Februar ");
                    break;
                case 3:
                    sb.append("Mart ");
                    break;
                case 4:
                    sb.append("April ");
                    break;
                case 5:
                    sb.append("Maj ");
                    break;
                case 6:
                    sb.append("Jun ");
                    break;
                case 7:
                    sb.append("Jul ");
                    break;
                case 8:
                    sb.append("Avgust");
                    break;
                case 9:
                    sb.append("Septembar ");
                    break;
                case 10:
                    sb.append("Oktobar ");
                    break;
                case 11:
                    sb.append("Novembar ");
                    break;
                case 12:
                    sb.append("Decembar ");
                    break;
            }

            sb.append(" ").append(day.getGodina()).append(".");
            calendarFragment.getCurrMonth().setText(sb.toString()); // ispisujw datum mesec i godinu na vrhu kalendara
        }

        holder.bind(day);
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        private TextView date;
        private ImageView imageView;
        private final Context context;
        private final Function<Integer, Void> onItemClicked;

        public ViewHolder(@NonNull View itemView, Context context, Function<Integer, Void> onItemClicked) {
            super(itemView);
            this.context = context;
            this.onItemClicked = onItemClicked;
        }

        public void bind(Dan dan) {
            initView(dan);
            initListeners();
        }

        private void initView(Dan dan) {

            imageView = itemView.findViewById(R.id.color_calendar_item);

            int low = 0;
            int mid = 0;
            int high = 0;
            int noPriority = -1;


            // brojim koji dan ima najvise obaveze
            for (int i = 0; i < dan.getObaveze().size(); i++) {
                if (dan.getObaveze().get(i).getDanPrioritet() == DanPrioritet.NIZAK_PRIORITET) {
                    low++;
                } else if (dan.getObaveze().get(i).getDanPrioritet() == DanPrioritet.SREDNJI_PRIORITET) {
                    mid++;
                } else if (dan.getObaveze().get(i).getDanPrioritet() == DanPrioritet.VISOK_PRIORITET) {
                    high++;
                }
            }

            int max = 0;

            if (high > max) {
                max = high;
            }

            if (mid > max) {
                max = mid;
            }

            if (low > max) {
                max = low;
            }

            if (low == max) {
                imageView.setBackgroundColor(Color.GREEN);
            }

            if (mid == max) {
                imageView.setBackgroundColor(Color.YELLOW);
            }

            if (high == max) {
                imageView.setBackgroundColor(Color.RED);
            }

            date = itemView.findViewById(R.id.date);
            date.setText(String.valueOf(dan.getDan()));
        }

        private void initListeners() {
            itemView.setOnClickListener(v -> {
                if (getAbsoluteAdapterPosition() != RecyclerView.NO_POSITION) {
                    onItemClicked.apply(getAbsoluteAdapterPosition());
                }
            });
        }
    }

    public void setCalendarFragment(CalendarFragment calendarFragment) {
        this.calendarFragment = calendarFragment;
    }
}