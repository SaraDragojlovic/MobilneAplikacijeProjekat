package raf.rs.prviprojekatmobilne.model;

public enum DanPrioritet {
    BEZ_PRIORITETA, NIZAK_PRIORITET, SREDNJI_PRIORITET, VISOK_PRIORITET
}
