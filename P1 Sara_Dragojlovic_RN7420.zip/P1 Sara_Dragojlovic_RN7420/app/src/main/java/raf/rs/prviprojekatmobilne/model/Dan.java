package raf.rs.prviprojekatmobilne.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Dan {
    private int id;
    private int obavezaId = 1;
    private int dan;
    private int mesec;
    private int godina;
    private int startTime;
    private int endStartTime;
    private int endTime;
    private int endEndTime;
    private List<Integer> times = new ArrayList<>();

    private List<DanObaveza> obaveze = new ArrayList<>();

    public Dan(int id,  int dan, int mesec, int godina, int brojObaveza) {
        this.id = id;

        this.dan = dan;
        this.mesec = mesec;
        this.godina = godina;

        Random random = new Random();

        for (int i=1; i <= brojObaveza; i++) {
            if(times.isEmpty()) {
                times.add(4);

                this.startTime = 4;
                this.endStartTime = 15;

                this.endTime = 5;
                this.endEndTime = 0;
            } else {
                int last_free_time = times.get(times.size() - 1);
                this.startTime = last_free_time + 1;

                switch (endStartTime){
                    case 0: this.endStartTime = 10; break;
                    case 1: this.endStartTime = 15; break;
                    case 2: this. endStartTime = 20; break;
                    case 3: this.endStartTime = 25; break;
                    case 4: this.endStartTime = 30; break;
                }

                this.endTime = this.startTime + 1; //zavrsava se za sat vremena
                this.endEndTime = 0; // zavrsava se u 00

                this.times.add(this.startTime);
            }

            obaveze.add(new DanObaveza(random.nextInt(4), random.nextInt(3), startTime, endStartTime, id, endTime, endEndTime, obavezaId++));
        }
    }

    public int getId() {
        return id;
    }

    public int getObavezaId() {
        return obavezaId;
    }

    public int getDan() {
        return dan;
    }

    public int getMesec() {
        return mesec;
    }

    public int getGodina() {
        return godina;
    }

    public int getStartTime() {
        return startTime;
    }

    public int getEndStartTime() {
        return endStartTime;
    }

    public int getEndTime() {
        return endTime;
    }

    public int getEndEndTime() {
        return endEndTime;
    }

    public List<Integer> getTimes() {
        return times;
    }

    public List<DanObaveza> getObaveze() {
        return obaveze;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setObavezaId(int obavezaId) {
        this.obavezaId = obavezaId;
    }

    public void setDan(int dan) {
        this.dan = dan;
    }

    public void setMesec(int mesec) {
        this.mesec = mesec;
    }

    public void setGodina(int godina) {
        this.godina = godina;
    }

    public void setStartTime(int startTime) {
        this.startTime = startTime;
    }

    public void setEndStartTime(int endStartTime) {
        this.endStartTime = endStartTime;
    }

    public void setEndTime(int endTime) {
        this.endTime = endTime;
    }

    public void setEndEndTime(int endEndTime) {
        this.endEndTime = endEndTime;
    }

    public void setTimes(List<Integer> times) {
        this.times = times;
    }

    public void setObaveze(List<DanObaveza> obaveze) {
        this.obaveze = obaveze;
    }
}
