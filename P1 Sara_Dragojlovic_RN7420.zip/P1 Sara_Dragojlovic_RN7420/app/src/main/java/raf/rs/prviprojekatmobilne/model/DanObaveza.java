package raf.rs.prviprojekatmobilne.model;

public class DanObaveza {

    private int dayId;
    private int idObaveze;
    private DanPrioritet danPrioritet;
    private String obaveze;
    private String opisObaveze;

    private int startTime;
    private int endStartTime;
    private int endTime;
    private int endEndTime;

    public DanObaveza(int idObaveze, int dayId) {
        this.idObaveze = idObaveze;
        this.dayId = dayId;
    }

    public DanObaveza(int danPrioritet, int obaveze, int  startTime, int endStartTime, int dayId, int endTime, int endEndTime, int idObaveze) {
        switch (danPrioritet){
            case 0: this.danPrioritet = DanPrioritet.BEZ_PRIORITETA; break;
            case 1: this.danPrioritet = DanPrioritet.NIZAK_PRIORITET; break;
            case 2: this.danPrioritet = DanPrioritet.SREDNJI_PRIORITET; break;
            default: this.danPrioritet = DanPrioritet.VISOK_PRIORITET; break;
        }

        switch (obaveze) {
            case 0: this.obaveze = "Kuca"; break;
            case 1: this. obaveze = "Fakultet"; break;
            case 2: this.obaveze = "Trening"; break;
        }

        switch (obaveze) {
            case 0: this.opisObaveze= "Raspremanje \n\nRucak\n"; break;
            case 1: this.opisObaveze = "Projekat iz mobilnih \n\n Predavanja\n"; break;
            case 2: this.opisObaveze = "Trening u 20h\n"; break;
        }

        this.startTime = startTime;
        this.endEndTime = endEndTime;
        this.endStartTime = endStartTime;
        this.endTime = endTime;

        this.dayId = dayId;
        this.idObaveze = idObaveze;

    }

    public int getDayId() {
        return dayId;
    }

    public void setDayId(int dayId) {
        this.dayId = dayId;
    }

    public int getIdObaveze() {
        return idObaveze;
    }

    public void setIdObaveze(int idObaveze) {
        this.idObaveze = idObaveze;
    }

    public DanPrioritet getDanPrioritet() {
        return danPrioritet;
    }

    public void setDanPrioritet(DanPrioritet danPrioritet) {
        this.danPrioritet = danPrioritet;
    }

    public String getObaveze() {
        return obaveze;
    }

    public void setObaveze(String obaveze) {
        this.obaveze = obaveze;
    }

    public String getOpisObaveze() {
        return opisObaveze;
    }

    public void setOpisObaveze(String opisObaveze) {
        this.opisObaveze = opisObaveze;
    }

    public int getStartTime() {
        return startTime;
    }

    public void setStartTime(int startTime) {
        this.startTime = startTime;
    }

    public int getEndStartTime() {
        return endStartTime;
    }

    public void setEndStartTime(int endStartTime) {
        this.endStartTime = endStartTime;
    }

    public int getEndTime() {
        return endTime;
    }

    public void setEndTime(int endTime) {
        this.endTime = endTime;
    }

    public int getEndEndTime() {
        return endEndTime;
    }

    public void setEndEndTime(int endEndTime) {
        this.endEndTime = endEndTime;
    }
}
