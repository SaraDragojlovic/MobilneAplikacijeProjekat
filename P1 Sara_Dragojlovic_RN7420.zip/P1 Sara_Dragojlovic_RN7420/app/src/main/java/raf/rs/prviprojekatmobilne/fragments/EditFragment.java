package raf.rs.prviprojekatmobilne.fragments;

import android.graphics.Color;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;

import raf.rs.prviprojekatmobilne.R;
import raf.rs.prviprojekatmobilne.model.Dan;
import raf.rs.prviprojekatmobilne.model.DanObaveza;
import raf.rs.prviprojekatmobilne.model.DanPrioritet;
import raf.rs.prviprojekatmobilne.viewmodel.MainViewModel;

public class EditFragment extends Fragment {
    private TextView datum;
    private TextView low;
    private TextView mid;
    private TextView high;
    private EditText obaveza;
    private EditText time;
    private EditText opisObaveze;
    private TextView saveBtn;
    private TextView cancelBtn;
    private Dan dan;
    private DanObaveza danObaveza;
    private MainViewModel mainViewModel;
    private View parentView;

    private int priority = 0;


    public EditFragment(){
        super(R.layout.fragment_edit);
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        init(view);
    }

    private void init(View view){
        initView(view);
        initListeners();
    }

    private void initView(View view){
        datum = view.findViewById(R.id.datum_edit);
        low = view.findViewById(R.id.low_edit);
        mid = view.findViewById(R.id.mid_edit);
        high = view.findViewById(R.id.high_edit);
        obaveza = view.findViewById(R.id.obaveza_edit);
        time = view.findViewById(R.id.time_edit);
        opisObaveze = view.findViewById(R.id.opis_obaveze_edit);
        cancelBtn = view.findViewById(R.id.cancel_btn_edit);
        saveBtn = view.findViewById(R.id.save_btn_edit);
        mainViewModel = new ViewModelProvider(getActivity()).get(MainViewModel.class);

        Bundle arguments = getArguments();
        dan = mainViewModel.getDayFromId(arguments.getInt("dayId"));

        for(DanObaveza dayObaveza1 : dan.getObaveze()){
            if(dayObaveza1.getIdObaveze() == arguments.getInt("obavezaId")){
                danObaveza = dayObaveza1;
                break;
            }
        }

        StringBuilder dateForComponent = new StringBuilder();

        switch (dan.getMesec()){
            case 1: dateForComponent.append("Januar "); break;
            case 2: dateForComponent.append("Februar "); break;
            case 3: dateForComponent.append("Mart ");break;
            case 4: dateForComponent.append("April "); break;
            case 5: dateForComponent.append("Maj ");break;
            case 6: dateForComponent.append("Jun ");break;
            case 7: dateForComponent.append("Jul ");break;
            case 8: dateForComponent.append("Avgust" ); break;
            case 9: dateForComponent.append("Septembar ");break;
            case 10: dateForComponent.append("Oktobar ");break;
            case 11: dateForComponent.append("Novembar ");break;
            case 12: dateForComponent.append("Decembar ");break;
        }
        dateForComponent.append(dan.getDan()).append(". ").append(dan.getGodina());
        datum.setText(dateForComponent.toString());

        StringBuilder stringBuilder = new StringBuilder();

        stringBuilder.append(danObaveza.getStartTime()).append(" : ")
                .append(danObaveza.getEndStartTime()).append(" - ")
                .append(danObaveza.getEndTime()).append(" : ");

        if(danObaveza.getEndEndTime() == 0){
            stringBuilder.append("00");
        }
        time.setText(stringBuilder.toString());

        opisObaveze.setText(danObaveza.getOpisObaveze());
        obaveza.setText(danObaveza.getObaveze());

        if(danObaveza.getDanPrioritet() == DanPrioritet.NIZAK_PRIORITET){
            low.setBackgroundColor(Color.GREEN);
            priority = 1;
        }else if(danObaveza.getDanPrioritet() == DanPrioritet.SREDNJI_PRIORITET){
            mid.setBackgroundColor(Color.YELLOW);
            priority = 2;
        }else if(danObaveza.getDanPrioritet() == DanPrioritet.VISOK_PRIORITET){
            high.setBackgroundColor(Color.RED);
            priority = 3;
        }

        parentView = view;
    }

    private void initListeners(){
        cancelBtn.setOnClickListener(view ->{
            Snackbar.make(parentView, "Da li ste sigurni?", Snackbar.LENGTH_SHORT)
                    .setAction("Odustani", new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            getActivity().getSupportFragmentManager().popBackStack();
                            Toast.makeText(getActivity(), "USPESNO STE ODUSTALI", Toast.LENGTH_LONG).show();
                        }
                    })
                    .show();
        });

        low.setOnClickListener(e -> {
            priority = 1;
            low.setBackgroundColor(Color.GREEN);
            mid.setBackgroundColor(Color.WHITE);
            high.setBackgroundColor(Color.WHITE);
        });

        mid.setOnClickListener(e -> {
            priority = 2;
            mid.setBackgroundColor(Color.YELLOW);
            low.setBackgroundColor(Color.WHITE);
            high.setBackgroundColor(Color.WHITE);
        });

        high.setOnClickListener(e -> {
            priority = 3;
            high.setBackgroundColor(Color.RED);
            mid.setBackgroundColor(Color.WHITE);
            low.setBackgroundColor(Color.WHITE);
        });

        saveBtn.setOnClickListener(view -> {

            if(priority == 1){
                danObaveza.setDanPrioritet(DanPrioritet.NIZAK_PRIORITET);
            }else if(priority == 2){
                danObaveza.setDanPrioritet(DanPrioritet.SREDNJI_PRIORITET);
            }else if(priority == 3){
                danObaveza.setDanPrioritet(DanPrioritet.VISOK_PRIORITET);
            }


            danObaveza.setObaveze(String.valueOf(obaveza.getText()));
            danObaveza.setOpisObaveze(String.valueOf(opisObaveze.getText()));

            String[] arg = String.valueOf(time.getText()).split(" ");



            danObaveza.setStartTime(Integer.valueOf(arg[0]));
            danObaveza.setEndStartTime(Integer.valueOf(arg[2]));
            danObaveza.setEndTime(Integer.valueOf(arg[4]));
            danObaveza.setEndEndTime(Integer.valueOf(arg[6]));


            getActivity().getSupportFragmentManager().popBackStack();
            Toast.makeText(getActivity(), "EDITED", Toast.LENGTH_LONG).show();
        });
    }

}