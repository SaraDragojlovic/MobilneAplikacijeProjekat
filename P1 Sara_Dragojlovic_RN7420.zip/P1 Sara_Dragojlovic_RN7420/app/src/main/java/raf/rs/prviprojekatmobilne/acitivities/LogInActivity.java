package raf.rs.prviprojekatmobilne.acitivities;

import static raf.rs.prviprojekatmobilne.acitivities.MainActivity.EMAIL;
import static raf.rs.prviprojekatmobilne.acitivities.MainActivity.LOGGED;
import static raf.rs.prviprojekatmobilne.acitivities.MainActivity.PASSWORD;
import static raf.rs.prviprojekatmobilne.acitivities.MainActivity.USERNAME;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import raf.rs.prviprojekatmobilne.MyApp;
import raf.rs.prviprojekatmobilne.R;

public class LogInActivity extends AppCompatActivity {

    private EditText email;
    private EditText username;
    private EditText password;
    private Button login;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log_in);
        init();
    }

    private void init(){
        initView();
        initListener();

    }

    private void initView(){
        email = findViewById(R.id.email_login);
        username = findViewById(R.id.username_login);
        password = findViewById(R.id.password_login);
        login = findViewById(R.id.button);

    }

    private void initListener(){
        login.setOnClickListener(view -> {
            String usernameText = String.valueOf(username.getText());
            String passwordText = String.valueOf(password.getText());
            String emailText = String.valueOf(email.getText());

            if(usernameText.isEmpty() || passwordText.isEmpty() || emailText.isEmpty()) {
                Toast.makeText(this, "Popunite sva polja", Toast.LENGTH_LONG).show();
                return;
            }

            if(passwordText.length() < 5 ) {
                Toast.makeText(this, "Sifra mora da ima minimum 5 karaktera", Toast.LENGTH_LONG).show();
                return;
            }

            boolean velikoSlovo = false;

            for(int i = 0; i < passwordText.length(); i++) {
                String slovo = passwordText.substring(i, i+1);
                if(slovo.equals(slovo.toUpperCase())){
                    velikoSlovo = true;
                }
            }

            if(!velikoSlovo) {
                Toast.makeText(this, "Sifra mora imati jedno veliko slovo", Toast.LENGTH_LONG).show();
                return;
            }

            String[] brojevi = passwordText.split("[1234567890]");

            if(brojevi.length < 2) {
                Toast.makeText(this, "Sifra mora imati bar jednu cifru", Toast.LENGTH_LONG).show();
                return;
            }

            String[] karakteri = passwordText.split("[~#^|$%&*!]");
            if(karakteri.length > 1) {
                Toast.makeText(this, "Sifra ne sme sadrzati specijalne karaktere", Toast.LENGTH_LONG).show();
                return;
            }

            SharedPreferences sharedPreferences = getSharedPreferences(getPackageName(), Context.MODE_PRIVATE);

            MyApp myApp = (MyApp) getApplication();
            if (String.valueOf(username.getText()).equals(myApp.getUsername()) && String.valueOf(password.getText()).equals(myApp.getPassword())) {
                sharedPreferences.edit()
                        .putString(MainActivity.USERNAME, String.valueOf(username.getText()))
                        .putString(MainActivity.PASSWORD, String.valueOf(password.getText()))
                        .putString(MainActivity.EMAIL, String.valueOf(email.getText()))
                        .putString(LOGGED, "ulogovan je korisnik")
                        .apply();

                Intent intent = new Intent(this, MainActivity.class);
                intent.putExtra(LOGGED, String.valueOf(username.getText()) + ", dobrodosli");
                startActivity(intent);
                finish();
            }else {
                Toast.makeText(this, "POKUSAJTE PONOVO", Toast.LENGTH_LONG).show();
            }
        });
    }
}