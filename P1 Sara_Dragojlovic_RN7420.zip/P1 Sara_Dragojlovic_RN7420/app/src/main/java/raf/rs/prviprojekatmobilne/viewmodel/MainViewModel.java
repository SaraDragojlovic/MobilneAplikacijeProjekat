package raf.rs.prviprojekatmobilne.viewmodel;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import raf.rs.prviprojekatmobilne.model.Dan;

public class MainViewModel extends ViewModel {
    public int id = 1;
    public static int months = 12;
    public int daysInMonth = 31;

    private final MutableLiveData<List<Dan>> days = new MutableLiveData<>();


    private List<Dan> daysList = new ArrayList<>();


    public MainViewModel(){
        for(int i = 1; i <= months; i++){
            for(int j = 1; j <= daysInMonth; j++){
                //generise broj obaveza
                daysList.add(new Dan(id++, j, i, 2023, new Random().nextInt(5) + 15));
            }
            if(daysInMonth == 30){
                daysInMonth = 31;
            }else {
                daysInMonth = 30;
            }
        }

        sort();
    }

    public LiveData<List<Dan>> getDays() {
        return days;
    }

    public Dan getDayFromId(int id){
        for(Dan day: daysList){
            if (day.getId() == id){
                return day;
            }
        }
        return null;
    }
    private void sort(){

        List<Dan> submitDays = new ArrayList<>(daysList);
        days.setValue(submitDays);


    }
}
