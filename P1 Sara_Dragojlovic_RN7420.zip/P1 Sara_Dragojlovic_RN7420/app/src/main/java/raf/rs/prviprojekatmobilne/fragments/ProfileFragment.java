package raf.rs.prviprojekatmobilne.fragments;

import static raf.rs.prviprojekatmobilne.acitivities.MainActivity.EMAIL;
import static raf.rs.prviprojekatmobilne.acitivities.MainActivity.USERNAME;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import raf.rs.prviprojekatmobilne.ClassForDark;
import raf.rs.prviprojekatmobilne.R;
import raf.rs.prviprojekatmobilne.acitivities.LogInActivity;


public class ProfileFragment extends Fragment {
    private TextView username;
    private TextView email;
    private Button editPassword;
    private  Button logout;
    private ImageView ikonica;


    public ProfileFragment() {
        super(R.layout.fragment_profile);
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        init(view);
    }

    private void init(View view){
        initView(view);
        initListeners();
    }

    private void initView(View view) {
        username = view.findViewById(R.id.name_profile);
        email = view.findViewById(R.id.email_profile);
        editPassword = view.findViewById(R.id.changePassword_profile);
        logout = view.findViewById(R.id.logout_profile);
        ikonica = view.findViewById(R.id.imageView);

        if(ClassForDark.getInstance().getPosition() == 1) {
            ikonica.setImageResource(R.drawable.profiledark);
        } else {
            ikonica.setImageResource(R.drawable.profile);
        }


        SharedPreferences sharedPreferences = getActivity().getSharedPreferences(getActivity().getPackageName(), Context.MODE_PRIVATE);
        username.setText(sharedPreferences.getString(USERNAME, ""));
        email.setText(sharedPreferences.getString(EMAIL, ""));
    }

    private void initListeners(){
        logout.setOnClickListener(e -> {

            SharedPreferences sharedPreferences = getActivity().getSharedPreferences(getActivity().getPackageName(), Context.MODE_PRIVATE);
            sharedPreferences.edit().clear().apply();
            Intent intent = new Intent(getActivity(), LogInActivity.class);
            startActivity(intent);
            getActivity().finish();
        });

    }
}