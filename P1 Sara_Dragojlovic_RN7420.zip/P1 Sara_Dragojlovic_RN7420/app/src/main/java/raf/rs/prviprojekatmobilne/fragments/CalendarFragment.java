package raf.rs.prviprojekatmobilne.fragments;

import static raf.rs.prviprojekatmobilne.acitivities.MainActivity.DAY_ID;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import raf.rs.prviprojekatmobilne.R;
import raf.rs.prviprojekatmobilne.adapters.MenuAdapter;
import raf.rs.prviprojekatmobilne.calendarRecycler.CalendarAdapter;
import raf.rs.prviprojekatmobilne.calendarRecycler.CalendarDiffCallBack;
import raf.rs.prviprojekatmobilne.viewmodel.MainViewModel;


public class CalendarFragment extends Fragment {

    private RecyclerView recyclerView;
    private MainViewModel mainViewModel;
    private CalendarAdapter calendarAdapter;
    private TextView currMonth;

    public CalendarFragment(){
        super(R.layout.fragment_calendar);
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        System.out.println("KREIRAO CALENDAR - ON");
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        init(view);
        System.out.println("KREIRAO CALENDAR - ONW");
    }

    @Override
    public void onResume() {
        super.onResume();
        initRecycler();
        initObservers();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        System.out.println("UNISTIO SE VIEW - CALENDAR FRAGMENT");
    }

    private void init(View view){
        initView(view);
        initRecycler();
        initObservers();

    }

    private void initView(View view){
        currMonth = view.findViewById(R.id.month_textView);
        mainViewModel = new ViewModelProvider(getActivity()).get(MainViewModel.class);
        recyclerView = view.findViewById(R.id.calendarRecycler);

    }

    private void initObservers(){
        mainViewModel.getDays().observe(this.getViewLifecycleOwner(), days -> {
            calendarAdapter.submitList(days);
        });
    }

    //kad se klikne na kalendaru na datum da izbaci novi prozor
    private void initRecycler(){
        calendarAdapter = new CalendarAdapter(new CalendarDiffCallBack(), day -> {
            Fragment fragment1 = getParentFragment();

            SharedPreferences sharedPreferences = getActivity().getSharedPreferences(getActivity().getPackageName(), Context.MODE_PRIVATE);
            sharedPreferences.edit().putInt(DAY_ID, day.getId()).apply();

            System.out.println("OVO JE DAY ID U CALENDARU KOJI PROSLEDJUJEM "+day.getId());

            ((MainFragment)fragment1).getViewPager().setCurrentItem(MenuAdapter.DAILY,false);

            return null;
        });
        calendarAdapter.setCalendarFragment(this);
        recyclerView.setLayoutManager(new GridLayoutManager(this.getContext(), 7, GridLayoutManager.VERTICAL,false));
        recyclerView.setAdapter(calendarAdapter);
    }

    public TextView getCurrMonth() {
        return currMonth;
    }
}