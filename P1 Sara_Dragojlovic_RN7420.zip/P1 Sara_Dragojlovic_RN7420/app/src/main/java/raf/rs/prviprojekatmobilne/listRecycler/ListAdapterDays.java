package raf.rs.prviprojekatmobilne.listRecycler;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import java.time.LocalTime;
import java.util.function.Function;

import raf.rs.prviprojekatmobilne.ClassForDark;
import raf.rs.prviprojekatmobilne.R;
import raf.rs.prviprojekatmobilne.model.DanObaveza;

public class ListAdapterDays extends ListAdapter<DanObaveza, ListAdapterDays.ViewHolder> {

    private final Function<DanObaveza, Void> onItemClicked;
    private final Function<DanObaveza, Void> onEditClicked;
    private final Function<DanObaveza, Void> onDeleteClicked;

    public ListAdapterDays(@NonNull DiffUtil.ItemCallback diffCallback,
                           Function<DanObaveza, Void> onItemClicked,
                           Function<DanObaveza, Void> onEditClicked,
                           Function<DanObaveza, Void> onDeleteClicked) {
        super(diffCallback);
        this.onItemClicked = onItemClicked;
        this.onEditClicked = onEditClicked;
        this.onDeleteClicked = onDeleteClicked;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_item, parent, false);
        return new ViewHolder(view, parent.getContext(), position -> {
            DanObaveza dayObaveza = getItem(position);
            onItemClicked.apply(dayObaveza);
            return null;
        }, position -> {
            DanObaveza dayObaveza = getItem(position);
            onEditClicked.apply(dayObaveza);
            return null;
        }, position -> {
            DanObaveza dayObaveza = getItem(position);
            onDeleteClicked.apply(dayObaveza);
            return null;
        });
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        DanObaveza dayObaveza = getItem(position);
        holder.bind(dayObaveza);
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        private final Context context;
        private TextView obaveza;
        private ImageView imageView;
        private ImageView imageColor;
        private ImageView editBtn;
        private ImageView deleteBtn;

        private TextView time;
        private ConstraintLayout constraintLayout;
        private ImageView clock;

        private final Function<Integer, Void> onItemClicked;
        private final Function<Integer, Void> onEditClicked;
        private final Function<Integer, Void> onDeleteClicked;

        public ViewHolder(@NonNull View itemView,
                          Context context,
                          Function<Integer, Void> onItemClicked,
                          Function<Integer, Void> onEditClicked,
                          Function<Integer, Void> onDeleteClicked) {
            super(itemView);
            this.context = context;
            this.onItemClicked = onItemClicked;
            this.onEditClicked = onEditClicked;
            this.onDeleteClicked = onDeleteClicked;

        }

        public void bind(DanObaveza dayObaveza){
            initView(dayObaveza);
            initListeners();
        }

        private void initView(DanObaveza dayObaveza){
            constraintLayout = itemView.findViewById(R.id.constraintlaylist);
            LocalTime currentTime = LocalTime.now();

            int konacno = currentTime.getHour();

            if(dayObaveza.getStartTime() < konacno) {
                constraintLayout.setBackgroundColor(Color.GRAY);
            }

            imageView = itemView.findViewById(R.id.list_item_image);
            imageColor = itemView.findViewById(R.id.color_list_item);

            switch (dayObaveza.getDanPrioritet()){
                case BEZ_PRIORITETA: imageColor.setBackgroundColor(Color.WHITE); break;
                case NIZAK_PRIORITET: imageColor.setBackgroundColor(Color.GREEN); break;
                case SREDNJI_PRIORITET: imageColor.setBackgroundColor(Color.YELLOW); break;
                default: imageColor.setBackgroundColor(Color.RED); break;
            }

            obaveza = itemView.findViewById(R.id.obaveza);
            obaveza.setText(dayObaveza.getObaveze());

            editBtn = itemView.findViewById(R.id.editBtn);
            deleteBtn = itemView.findViewById(R.id.deleteBtn);
            time = itemView.findViewById(R.id.time_list_item);
            clock  = itemView.findViewById(R.id.clock_picture);

            if(ClassForDark.getInstance().getPosition() == 1) {
                deleteBtn.setImageResource(R.drawable.deletedark);
                editBtn.setImageResource(R.drawable.editdark);
                clock.setImageResource(R.drawable.clockdark);
            } else {
                deleteBtn.setImageResource(R.drawable.delete);
                editBtn.setImageResource(R.drawable.edit);
                clock.setImageResource(R.drawable.clock);
            }

            StringBuilder stringBuilder = new StringBuilder();

            stringBuilder.append(dayObaveza.getStartTime()).append(" : ")
                    .append(dayObaveza.getEndStartTime()).append(" - ")
                    .append(dayObaveza.getEndTime()).append(" : ");

            if(dayObaveza.getEndEndTime() == 0){
                stringBuilder.append("00");
            }

            time.setText(stringBuilder.toString());
        }

        private void initListeners(){
            itemView.setOnClickListener(v -> {
                if(getAbsoluteAdapterPosition() != RecyclerView.NO_POSITION){
                    onItemClicked.apply(getAbsoluteAdapterPosition());
                }
            });

            editBtn.setOnClickListener(v -> {
                if(getAbsoluteAdapterPosition() != RecyclerView.NO_POSITION){
                    onEditClicked.apply(getAbsoluteAdapterPosition());
                }
            });

            deleteBtn.setOnClickListener(v -> {
                if(getAbsoluteAdapterPosition() != RecyclerView.NO_POSITION){
                    onDeleteClicked.apply(getAbsoluteAdapterPosition());
                }
            });
        }
    }
}