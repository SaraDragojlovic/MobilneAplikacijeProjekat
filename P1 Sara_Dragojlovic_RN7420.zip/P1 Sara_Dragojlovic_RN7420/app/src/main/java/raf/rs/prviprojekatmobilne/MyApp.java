package raf.rs.prviprojekatmobilne;

import android.app.Application;
import android.content.res.Configuration;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import timber.log.Timber;

public class MyApp extends Application {
    private String username = "";
    private String password = "";

    @Override
    public void onCreate() {
        super.onCreate();
        ClassForDark classForDark = ClassForDark.getInstance();
        if(isDarkTheme()){
            classForDark.setPosition(1);
        }else {
            classForDark.setPosition(0);
        }
        readFile();
        Timber.plant(new Timber.DebugTree());
    }

    private void readFile() {
        InputStream is = this.getResources().openRawResource(R.raw.my);
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(is));
        String str = null;
        try {
            while ((str = bufferedReader.readLine()) != null) {
                String[] arg = str.split(",");
                username = arg[0];
                password = arg[1];
            }
            is.close();
            bufferedReader.close();
        } catch (IOException e) {
            e.printStackTrace(); }

    }
    public String getPassword() {
        return password;
    }

    public String getUsername() {
        return username;
    }

    public boolean isDarkTheme() {
        int currentNightMode = getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
        return currentNightMode == Configuration.UI_MODE_NIGHT_YES;
    }
}
