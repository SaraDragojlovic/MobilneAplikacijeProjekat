package raf.rs.prviprojekatmobilne.fragments;

import static raf.rs.prviprojekatmobilne.acitivities.MainActivity.DAY_ID;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import raf.rs.prviprojekatmobilne.R;
import raf.rs.prviprojekatmobilne.listRecycler.ListAdapterDays;
import raf.rs.prviprojekatmobilne.listRecycler.ListDiffItemCallBack;
import raf.rs.prviprojekatmobilne.model.Dan;
import raf.rs.prviprojekatmobilne.model.DanObaveza;
import raf.rs.prviprojekatmobilne.model.DanPrioritet;
import raf.rs.prviprojekatmobilne.viewmodel.MainViewModel;

public class LowPriorityFragment extends Fragment {

    private RecyclerView recyclerView;
    private MainViewModel mainViewModel;
    private ListAdapterDays listAdapterDays;

    public LowPriorityFragment(){
        super(R.layout.fragment_low_priority);
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        init(view);
    }

    @Override
    public void onResume() {
        super.onResume();
        initObservers();
        System.out.println("DESIO SE RESUME NA LOW");
    }

    private void init(View view){
        initView(view);
        initRecycler();
    }


    private void initView(View view){
        mainViewModel = new ViewModelProvider(getActivity()).get(MainViewModel.class);
        recyclerView = view.findViewById(R.id.low_list_recycler);
    }

    public void initObservers(){
        LocalTime currentTime = LocalTime.now();

        // Extract the hour from the current time
        int konacno = currentTime.getHour();


        SharedPreferences sharedPreferences = getActivity().getSharedPreferences(getActivity().getPackageName(), Context.MODE_PRIVATE);
        int dayId = sharedPreferences.getInt(DAY_ID, 1);
        Dan day = mainViewModel.getDayFromId(dayId);

        List<DanObaveza> lowObaveze = new ArrayList<>();

        for(DanObaveza obaveza : day.getObaveze()){
            if(obaveza.getDanPrioritet() == DanPrioritet.NIZAK_PRIORITET){
                if(obaveza.getStartTime() >= konacno)
                    lowObaveze.add(obaveza);
            }
        }

        listAdapterDays.submitList(lowObaveze);
    }

    private void initRecycler(){
        listAdapterDays = new ListAdapterDays(new ListDiffItemCallBack(), obaveza -> {
            DetailListFragment detailListFragment = new DetailListFragment();
            Bundle bundle = new Bundle();
            bundle.putInt("dayId", obaveza.getDayId());
            bundle.putInt("obavezaId", obaveza.getIdObaveze());
            detailListFragment.setArguments(bundle);
            Objects.requireNonNull(getActivity()).getSupportFragmentManager().beginTransaction().replace(R.id.MainFragmentContainer,detailListFragment).addToBackStack(null).commit();
            return null;
        }, obavezaEdit -> {
            EditFragment editFragment = new EditFragment();
            Bundle bundle = new Bundle();
            bundle.putInt("dayId", obavezaEdit.getDayId());
            bundle.putInt("obavezaId", obavezaEdit.getIdObaveze());
            editFragment.setArguments(bundle);
            Objects.requireNonNull(getActivity()).getSupportFragmentManager().beginTransaction().replace(R.id.MainFragmentContainer,editFragment).addToBackStack(null).commit();
            return null;
        }, deleteObaveza -> {

            Dan day = mainViewModel.getDayFromId(deleteObaveza.getDayId());
            day.getObaveze().remove(deleteObaveza);
            initObservers();
            return null;
        });
        recyclerView.setLayoutManager(new LinearLayoutManager(this.getContext()));
        recyclerView.setAdapter(listAdapterDays);
    }

    public void setItems(ArrayList<DanObaveza> items){
        listAdapterDays.submitList(items);
    }
}