package raf.rs.prviprojekatmobilne.calendarRecycler;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;

import raf.rs.prviprojekatmobilne.model.Dan;

public class CalendarDiffCallBack extends DiffUtil.ItemCallback<Dan> {
    @Override
    public boolean areItemsTheSame(@NonNull Dan oldItem, @NonNull Dan newItem) {
        return oldItem.getId() == newItem.getId();
    }

    @Override
    public boolean areContentsTheSame(@NonNull Dan oldItem, @NonNull Dan newItem) {
        return  (oldItem.getDan() == newItem.getDan())
                && (oldItem.getMesec() == newItem.getMesec())
                && (oldItem.getGodina() == newItem.getGodina());
    }
}