package raf.rs.prviprojekatmobilne.acitivities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.splashscreen.SplashScreen;
import androidx.fragment.app.FragmentTransaction;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;

import raf.rs.prviprojekatmobilne.R;
import raf.rs.prviprojekatmobilne.fragments.MainFragment;


public class MainActivity extends AppCompatActivity {

    public static final String LOGGED = "Da li je neko ulogovan";
    public static final String USERNAME = "USERNAME";
    public static final String PASSWORD = "PASSWORD";
    public static final String EMAIL = "EMAIL";
    public static final String DAY_ID = "trenutan dan";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        init();
        setContentView(R.layout.activity_main);
    }

    private void init(){

        SplashScreen splashScreen = SplashScreen.installSplashScreen(this);
        splashScreen.setKeepOnScreenCondition(() -> {
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {

                    SharedPreferences sharedPreferences = getSharedPreferences(getPackageName(), Context.MODE_PRIVATE);
                    String logged = sharedPreferences.getString(LOGGED, "");

                    if(logged == null || logged.equals("")) {
                        Intent intent = new Intent(MainActivity.this, LogInActivity.class);
                        startActivity(intent);
                        finish();
                    }
                }
            }, 2000);
            return false;
        });
        initFragments();

    }



    private void initFragments() {
        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        fragmentTransaction.add(R.id.MainFragmentContainer, new MainFragment()).addToBackStack(null);
        fragmentTransaction.commit();

    }

}