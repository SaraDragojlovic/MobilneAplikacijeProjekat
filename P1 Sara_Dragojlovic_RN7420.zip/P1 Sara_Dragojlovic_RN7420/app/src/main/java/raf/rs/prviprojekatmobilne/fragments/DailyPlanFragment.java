package raf.rs.prviprojekatmobilne.fragments;

import static raf.rs.prviprojekatmobilne.acitivities.MainActivity.DAY_ID;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.viewpager.widget.ViewPager;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.SearchView;
import android.widget.TextView;

import com.google.android.material.tabs.TabLayout;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import raf.rs.prviprojekatmobilne.ClassForDark;
import raf.rs.prviprojekatmobilne.R;
import raf.rs.prviprojekatmobilne.adapters.TabsAdapter;
import raf.rs.prviprojekatmobilne.model.Dan;
import raf.rs.prviprojekatmobilne.model.DanObaveza;
import raf.rs.prviprojekatmobilne.model.DanPrioritet;
import raf.rs.prviprojekatmobilne.viewmodel.MainViewModel;

public class DailyPlanFragment extends Fragment {

    private TabLayout tabLayout;
    private ViewPager viewPager;
    private SearchView searchView;
    private TextView day_month_year_txt;
    private MainViewModel mainViewModel;
    private CheckBox checkBox;

    private ImageView novaObaveza;

    private Dan day;

    private int position;
    public DailyPlanFragment() {
        super(R.layout.fragment_daily_plan);
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        init(view);
    }

    @Override
    public void onResume() {
        super.onResume();
        initObservers();
    }

    private void init(View view){
        initView(view);
        initObservers();
        initTabs();
        initListeners();
    }

    private void initView(View view){
        tabLayout = view.findViewById(R.id.tabLayout);
        viewPager = view.findViewById(R.id.daily_viewPager);
        day_month_year_txt = view.findViewById(R.id.daily_datum);
        searchView = view.findViewById(R.id.daily_searchViiew);
        mainViewModel = new ViewModelProvider(getActivity()).get(MainViewModel.class);
        checkBox = view.findViewById(R.id.daily_checkBox);
        novaObaveza = view.findViewById(R.id.addView);
        if(ClassForDark.getInstance().getPosition() ==1) {
            novaObaveza.setImageResource(R.drawable.addicondark);
        } else{
            novaObaveza.setImageResource(R.drawable.addicon);
        }

    }

    private void initTabs(){
        viewPager.setAdapter(new TabsAdapter(getChildFragmentManager()));
        tabLayout.setupWithViewPager(viewPager);
    }

    private void initObservers(){
        SharedPreferences sharedPreferences = getActivity().getSharedPreferences(getActivity().getPackageName(), Context.MODE_PRIVATE);
        int dayId = sharedPreferences.getInt(DAY_ID, 1);
        day = mainViewModel.getDayFromId(dayId);

        StringBuilder sb = new StringBuilder();

        switch (day.getMesec()){
            case 1: sb.append("Januar "); break;
            case 2: sb.append("Februar "); break;
            case 3: sb.append("Mart ");break;
            case 4: sb.append("April "); break;
            case 5: sb.append("Maj ");break;
            case 6: sb.append("Jun ");break;
            case 7: sb.append("Jul ");break;
            case 8: sb.append("Avgust" ); break;
            case 9: sb.append("Septembar ");break;
            case 10: sb.append("Oktobar ");break;
            case 11: sb.append("Novembar ");break;
            case 12: sb.append("Decembar ");break;
        }

        sb.append(" ").append(day.getDan()).append(" ").append(day.getGodina()).append(".");

        day_month_year_txt.setText(sb.toString());
    }

    private void initListeners(){

        int time = (int) System.currentTimeMillis();

        int time2 = time/1000;
        int time3 = time2/3600;
        int konacno = time3/24 - 5;

        novaObaveza.setOnClickListener(e -> {
            Bundle arguments = new Bundle(); //setujem agrumente view-u
            arguments.putInt("dayId", day.getId());
            NewFragment newFragment = new NewFragment();
            newFragment.setArguments(arguments);
            getActivity().getSupportFragmentManager().beginTransaction().replace(R.id.MainFragmentContainer, newFragment).addToBackStack(null).commit();
        });




        // za filtriranje teksta
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query){
                System.out.println("OVO JE TEKST : " + query);

                Fragment fragment = ((TabsAdapter) Objects.requireNonNull(viewPager.getAdapter())).getFragments(position);
                List<DanObaveza> filteredList = day.getObaveze().stream().filter(dayObaveza -> dayObaveza.getObaveze().toLowerCase().contains(query.toString().toLowerCase())).collect(Collectors.toList());

                System.out.println(filteredList);

                if(fragment instanceof HighPriorityFragment){
                    System.out.println("NALAZIM SE U HIGH");

                    List<DanObaveza> sredjeno = new ArrayList<>();

                    for(DanObaveza obaveza : filteredList){
                        if(obaveza.getDanPrioritet() == DanPrioritet.VISOK_PRIORITET){
                            sredjeno.add(obaveza);
                        }
                    }

                    ((HighPriorityFragment)fragment).setItems((ArrayList<DanObaveza>) sredjeno);
                } else if(fragment instanceof MidPriorityFragment){

                    List<DanObaveza> sredjeno = new ArrayList<>();

                    for(DanObaveza dayObaveza : filteredList){
                        if(dayObaveza.getDanPrioritet() == DanPrioritet.SREDNJI_PRIORITET){
                            sredjeno.add(dayObaveza);
                        }
                    }
                    ((MidPriorityFragment)fragment).setItems((ArrayList<DanObaveza>) sredjeno);
                } else if(fragment instanceof LowPriorityFragment){

                    List<DanObaveza> sredjeno = new ArrayList<>();

                    for(DanObaveza dayObaveza : filteredList){
                        if(dayObaveza.getDanPrioritet() == DanPrioritet.NIZAK_PRIORITET){
                            sredjeno.add(dayObaveza);
                        }
                    }
                    ((LowPriorityFragment)fragment).setItems((ArrayList<DanObaveza>) sredjeno);
                }

                return true;
            }

            @Override
            public boolean onQueryTextChange(String newText) {

                return false;
            }
        });


        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                position = tab.getPosition();
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
                // Do nothing
            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {
                // Do nothing
            }
        });

        checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

                Fragment fragment = null;

                System.out.println(getChildFragmentManager().getFragments());
                for(Fragment fragment1 : getChildFragmentManager().getFragments()){
                    if(position == 0 && fragment1 instanceof LowPriorityFragment){
                        fragment = fragment1;
                    }else if(position == 1 && fragment1 instanceof MidPriorityFragment){
                        fragment = fragment1;
                    }else if(position == 2 && fragment1 instanceof HighPriorityFragment){
                        fragment = fragment1;
                    }else if(position == 3 && fragment1 instanceof AllPriorityFragment){
                        fragment = fragment1;
                    }
                }

                if (isChecked) {

                    System.out.println("CHECKED JE");
                    System.out.println(fragment);

                    if(fragment instanceof HighPriorityFragment){
                        System.out.println("NALAZIM SE U HIGH");

                        List<DanObaveza> sredjeno = new ArrayList<>();

                        for(DanObaveza dayObaveza : day.getObaveze()){
                            if(dayObaveza.getDanPrioritet() == DanPrioritet.VISOK_PRIORITET){
                                sredjeno.add(dayObaveza);
                            }
                        }((HighPriorityFragment)fragment).setItems((ArrayList<DanObaveza>) sredjeno);
                    } else if(fragment instanceof MidPriorityFragment){

                        System.out.println("OVO JE MID PRIORiTY");
                        List<DanObaveza> sredjeno = new ArrayList<>();

                        for(DanObaveza dayObaveza : day.getObaveze()){
                            if(dayObaveza.getDanPrioritet() == DanPrioritet.SREDNJI_PRIORITET){
                                sredjeno.add(dayObaveza);
                            }
                        }
                        ((MidPriorityFragment)fragment).setItems((ArrayList<DanObaveza>) sredjeno);
                    } else if(fragment instanceof LowPriorityFragment){

                        System.out.println("OVO JE LOW PRIORiTY");

                        List<DanObaveza> sredjeno = new ArrayList<>();

                        for(DanObaveza dayObaveza : day.getObaveze()){
                            if(dayObaveza.getDanPrioritet() == DanPrioritet.NIZAK_PRIORITET){
                                sredjeno.add(dayObaveza);
                            }
                        }
                        ((LowPriorityFragment)fragment).setItems((ArrayList<DanObaveza>) sredjeno);
                    }else if(fragment instanceof AllPriorityFragment){

                        List<DanObaveza> sredjeno = new ArrayList<>();

                        for(DanObaveza dayObaveza : day.getObaveze()){
                            if(dayObaveza.getDanPrioritet() == DanPrioritet.NIZAK_PRIORITET ||
                                    dayObaveza.getDanPrioritet() == DanPrioritet.SREDNJI_PRIORITET ||
                                    dayObaveza.getDanPrioritet() == DanPrioritet.VISOK_PRIORITET){
                                sredjeno.add(dayObaveza);
                            }
                        }
                        ((AllPriorityFragment)fragment).setItems((ArrayList<DanObaveza>) sredjeno);
                    }

                } else {

                    if(fragment instanceof HighPriorityFragment){
                        ((HighPriorityFragment)fragment).initObservers();
                    } else if(fragment instanceof MidPriorityFragment){
                        ((MidPriorityFragment)fragment).initObservers();
                    } else if(fragment instanceof LowPriorityFragment){
                        ((LowPriorityFragment)fragment).initObservers();
                    }else if(fragment instanceof AllPriorityFragment){
                        ((AllPriorityFragment)fragment).initObservers();
                    }
                }
            }
        });
    }
    }