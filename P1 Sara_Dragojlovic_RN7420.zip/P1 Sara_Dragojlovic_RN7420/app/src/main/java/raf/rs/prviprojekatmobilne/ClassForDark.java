package raf.rs.prviprojekatmobilne;

public class ClassForDark {

    public static ClassForDark instance;
    private int position;

    public static ClassForDark getInstance() {
        if(instance == null){
            instance = new ClassForDark();
        }
        return instance;
    }

    public int getPosition() {
        return position;
    }

    public void setPosition(int position) {
        this.position = position;
    }
}
