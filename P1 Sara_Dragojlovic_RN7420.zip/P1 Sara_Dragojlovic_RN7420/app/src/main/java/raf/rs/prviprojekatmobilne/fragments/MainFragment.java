package raf.rs.prviprojekatmobilne.fragments;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;


import android.view.View;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import raf.rs.prviprojekatmobilne.R;
import raf.rs.prviprojekatmobilne.adapters.MenuAdapter;


public class MainFragment extends Fragment {

    private ViewPager viewPager;

    public MainFragment(){
        super(R.layout.fragment_main);
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        init(view);
    }

    private void init(View view){
        initView(view);
        initNavigation(view);
    }

    private void initView(View view){
        viewPager = view.findViewById(R.id.mainViewPager);
        viewPager.setAdapter(new MenuAdapter(getChildFragmentManager()));
    }

    private void initNavigation(View view){
        ((BottomNavigationView)view.findViewById(R.id.bottomNav)).setOnItemSelectedListener(item->{
            switch (item.getItemId()){
                case R.id.profile: viewPager.setCurrentItem(MenuAdapter.PROFILE, false); break;
                case R.id.calendar: viewPager.setCurrentItem(MenuAdapter.CALENDAR, false); break;
                case R.id.dailyPlan: viewPager.setCurrentItem(MenuAdapter.DAILY, false); break;
                default: viewPager.setCurrentItem(MenuAdapter.PROFILE, false); break;
            }

            return true;
        });
    }

    public ViewPager getViewPager() {
        return viewPager;
    }
}