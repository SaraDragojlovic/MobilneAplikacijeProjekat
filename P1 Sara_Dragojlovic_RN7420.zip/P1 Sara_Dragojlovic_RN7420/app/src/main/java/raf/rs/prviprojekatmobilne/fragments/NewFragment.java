package raf.rs.prviprojekatmobilne.fragments;

import android.graphics.Color;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;

import raf.rs.prviprojekatmobilne.R;
import raf.rs.prviprojekatmobilne.model.Dan;
import raf.rs.prviprojekatmobilne.model.DanObaveza;
import raf.rs.prviprojekatmobilne.model.DanPrioritet;
import raf.rs.prviprojekatmobilne.viewmodel.MainViewModel;


public class NewFragment extends Fragment {

    private TextView datum;
    private TextView low;
    private TextView mid;
    private TextView high;
    private EditText obaveza;
    private EditText time;
    private EditText opisObaveze;
    private TextView saveBtn;
    private TextView cancelBtn;
    private Dan dan;
    private MainViewModel mainViewModel;
    private View parentView;
    private int priority = 0;

    public NewFragment(){
        super(R.layout.fragment_new);
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        init(view);
    }

    private void init(View view){
        initView(view);
        initListeners();
    }

    private void initView(View view){
        datum = view.findViewById(R.id.datum_new);
        low = view.findViewById(R.id.low_new);
        mid = view.findViewById(R.id.mid_new);
        high = view.findViewById(R.id.high_new);
        obaveza = view.findViewById(R.id.obaveza_new);
        time = view.findViewById(R.id.time_new);
        opisObaveze = view.findViewById(R.id.opis_obaveze_new);
        cancelBtn = view.findViewById(R.id.cancel_btn_new);
        saveBtn = view.findViewById(R.id.save_btn_new);
        mainViewModel = new ViewModelProvider(getActivity()).get(MainViewModel.class);

        Bundle arguments = getArguments();
        dan = mainViewModel.getDayFromId(arguments.getInt("dayId"));

        StringBuilder dateForComponent = new StringBuilder();

        switch (dan.getMesec()){
            case 1: dateForComponent.append("Januar "); break;
            case 2: dateForComponent.append("Februar "); break;
            case 3: dateForComponent.append("Mart ");break;
            case 4: dateForComponent.append("April "); break;
            case 5: dateForComponent.append("Maj ");break;
            case 6: dateForComponent.append("Jun ");break;
            case 7: dateForComponent.append("Jul ");break;
            case 8: dateForComponent.append("Avgust" ); break;
            case 9: dateForComponent.append("Septembar ");break;
            case 10: dateForComponent.append("Oktobar ");break;
            case 11: dateForComponent.append("Novembar ");break;
            case 12: dateForComponent.append("Decembar ");break;
        }
        dateForComponent.append(dan.getDan()).append(". ").append(dan.getGodina());
        datum.setText(dateForComponent.toString());

        parentView = view;
    }

    private void initListeners(){
        cancelBtn.setOnClickListener(view ->{
            Snackbar.make(parentView, "Da li stvarno zelite da odustanete ?!", Snackbar.LENGTH_SHORT)
                    .setAction("Odustani", new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            getActivity().getSupportFragmentManager().popBackStack();
                            Toast.makeText(getActivity(), "USPESNO STE ODUSTALI", Toast.LENGTH_LONG).show();
                        }
                    })
                    .show();
        });

        low.setOnClickListener(e -> {
            priority = 1;
            low.setBackgroundColor(Color.GREEN);
            mid.setBackgroundColor(Color.WHITE);
            high.setBackgroundColor(Color.WHITE);
        });

        mid.setOnClickListener(e -> {
            priority = 2;
            mid.setBackgroundColor(Color.YELLOW);
            low.setBackgroundColor(Color.WHITE);
            high.setBackgroundColor(Color.WHITE);
        });

        high.setOnClickListener(e -> {
            priority = 3;
            high.setBackgroundColor(Color.RED);
            mid.setBackgroundColor(Color.WHITE);
            low.setBackgroundColor(Color.WHITE);
        });

        saveBtn.setOnClickListener(view -> {

            DanPrioritet danPrioritet = null;

            if(priority == 1){
                danPrioritet = DanPrioritet.NIZAK_PRIORITET;
            }else if(priority == 2){
                danPrioritet = DanPrioritet.SREDNJI_PRIORITET;
            }else if(priority == 3){
                danPrioritet = DanPrioritet.VISOK_PRIORITET;
            }


            String obavezaText = String.valueOf(obaveza.getText());
            String dayObavezaText = String.valueOf(opisObaveze.getText());

            String[] arg = String.valueOf(time.getText()).split(" ");



            int startTime = Integer.parseInt(arg[0]);
            int startEndTime = Integer.parseInt(arg[2]);
            int endTime = Integer.parseInt(arg[4]);
            int endEndTime = Integer.parseInt(arg[6]);

            DanObaveza danObaveza = new DanObaveza(dan.getObaveze().size(), dan.getId());

            danObaveza.setOpisObaveze(dayObavezaText);
            danObaveza.setObaveze(obavezaText);
            danObaveza.setStartTime(startTime);
            danObaveza.setEndStartTime(startEndTime);
            danObaveza.setEndTime(endTime);
            danObaveza.setEndEndTime(endEndTime);
            danObaveza.setDanPrioritet(danPrioritet);

            dan.getObaveze().add(danObaveza);

            getActivity().getSupportFragmentManager().popBackStack();
            Toast.makeText(getActivity(), "Dodali ste priority", Toast.LENGTH_LONG).show();
        });
    }
}