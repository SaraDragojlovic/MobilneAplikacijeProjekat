package raf.rs.prviprojekatmobilne.adapters;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

import raf.rs.prviprojekatmobilne.fragments.CalendarFragment;
import raf.rs.prviprojekatmobilne.fragments.DailyPlanFragment;
import raf.rs.prviprojekatmobilne.fragments.ProfileFragment;

public class MenuAdapter extends FragmentPagerAdapter {

    public static final int COUNT = 3;
    public static final int CALENDAR = 0;
    public static final int DAILY = 1;
    public static final int PROFILE = 2;


    public MenuAdapter(@NonNull FragmentManager fm) {
        super(fm, BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT);
    }

    @NonNull
    @Override
    public Fragment getItem(int position) {
        switch (position){
            case 2: return new ProfileFragment();
            case 0: return new CalendarFragment();
            case 1: return new DailyPlanFragment();
            default: return new ProfileFragment();
        }
    }

    @Override
    public int getCount() {
        return COUNT;
    }
}
