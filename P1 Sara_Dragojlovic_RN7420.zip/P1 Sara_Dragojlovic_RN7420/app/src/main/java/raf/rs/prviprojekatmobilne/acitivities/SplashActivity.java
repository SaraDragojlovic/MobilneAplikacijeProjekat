package raf.rs.prviprojekatmobilne.acitivities;

import static raf.rs.prviprojekatmobilne.acitivities.MainActivity.LOGGED;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.splashscreen.SplashScreen;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.widget.ImageView;


import raf.rs.prviprojekatmobilne.ClassForDark;
import raf.rs.prviprojekatmobilne.R;

public class SplashActivity extends AppCompatActivity {

    private ImageView imageView;

    public SplashActivity(){

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        imageView = findViewById(R.id.splashScreenIcon);
        if(ClassForDark.getInstance().getPosition() == 1) {
            imageView.setImageResource(R.drawable.splash_screenblack);
        } else {
            imageView.setImageResource(R.drawable.splash_screen);
        }

        SplashScreen splashScreen = SplashScreen.installSplashScreen(this);
        splashScreen.setKeepOnScreenCondition(()->{

            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    SharedPreferences sharedPreferences = getSharedPreferences(getPackageName(), Context.MODE_PRIVATE);
                    String message = sharedPreferences.getString(LOGGED,"");
                    if(message == null || message.equals("")){
                        Intent intent = new Intent(SplashActivity.this, LogInActivity.class);
                        startActivity(intent);
                        finish();
                    }else {
                        Intent intent = new Intent(SplashActivity.this, MainActivity.class);
                        startActivity(intent);
                        finish();
                    }
                }
            }, 2000);
            return false;
        });
    }
}