package raf.rs.prviprojekatmobilne.fragments;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;

import java.util.Objects;

import raf.rs.prviprojekatmobilne.R;
import raf.rs.prviprojekatmobilne.model.Dan;
import raf.rs.prviprojekatmobilne.model.DanObaveza;
import raf.rs.prviprojekatmobilne.viewmodel.MainViewModel;


public class DetailListFragment extends Fragment {

    private TextView datum;
    private TextView time;
    private TextView nazivObaveze;
    private TextView detealjiObaveze;
    private Button edit;
    private Button delete;
    private MainViewModel mainViewModel;
    private Dan day;
    private View parentLayout;
    private DanObaveza dayObaveza;

    public DetailListFragment(){
        super(R.layout.fragment_detail_list);
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        init(view);
    }

    private void init(View view){
        initView(view);
        initListeners();
    }

    private void initView(View view){
        datum = view.findViewById(R.id.datum_detail);
        time = view.findViewById(R.id.vreme_detail);
        nazivObaveze = view.findViewById(R.id.obaveza_detail);
        detealjiObaveze = view.findViewById(R.id.opis_obaveze_detail);
        edit = view.findViewById(R.id.edit_btn_detail);
        delete = view.findViewById(R.id.delete_btn_detail);

        mainViewModel = new ViewModelProvider(getActivity()).get(MainViewModel.class);

        Bundle arguments = getArguments();
        day = mainViewModel.getDayFromId(arguments.getInt("dayId"));

        for(DanObaveza dayObaveza1 : day.getObaveze()){
            if(dayObaveza1.getIdObaveze() == arguments.getInt("obavezaId")){
                dayObaveza = dayObaveza1;
                break;
            }
        }

        StringBuilder dateForComponent = new StringBuilder();

        switch (day.getMesec()){
            case 1: dateForComponent.append("Januar "); break;
            case 2: dateForComponent.append("Februar "); break;
            case 3: dateForComponent.append("Mart ");break;
            case 4: dateForComponent.append("April "); break;
            case 5: dateForComponent.append("Maj ");break;
            case 6: dateForComponent.append("Jun ");break;
            case 7: dateForComponent.append("Jul ");break;
            case 8: dateForComponent.append("Avgust" ); break;
            case 9: dateForComponent.append("Septembar ");break;
            case 10: dateForComponent.append("Oktobar ");break;
            case 11: dateForComponent.append("Novembar ");break;
            case 12: dateForComponent.append("Decembar ");break;
        }
        dateForComponent.append(day.getDan()).append(". ").append(day.getGodina());
        datum.setText(dateForComponent.toString());

        StringBuilder stringBuilder = new StringBuilder();

        stringBuilder.append(dayObaveza.getStartTime()).append(" : ")
                .append(dayObaveza.getEndStartTime()).append(" - ")
                .append(dayObaveza.getEndTime()).append(" : ");

        if(dayObaveza.getEndEndTime() == 0){
            stringBuilder.append("00");
        }

        time.setText(stringBuilder.toString());

        nazivObaveze.setText(dayObaveza.getObaveze());
        detealjiObaveze.setText( "\n" + dayObaveza.getOpisObaveze());

        parentLayout = view;
    }

    private void initListeners(){
        edit.setOnClickListener(e->{
            EditFragment editFragment = new EditFragment();
            Bundle bundle = new Bundle();
            bundle.putInt("dayId", day.getId());
            bundle.putInt("obavezaId", dayObaveza.getIdObaveze());
            editFragment.setArguments(bundle);
            Objects.requireNonNull(getActivity()).getSupportFragmentManager().beginTransaction().replace(R.id.MainFragmentContainer,editFragment).addToBackStack(null).commit();
        });

        delete.setOnClickListener(e->{
            Snackbar.make(parentLayout, "Da li ste sigurni da zelite uklonite?", Snackbar.LENGTH_SHORT)
                    .setAction("Ukloni", new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            day.getObaveze().remove(dayObaveza);
                            getActivity().getSupportFragmentManager().popBackStack();
                            Toast.makeText(getActivity(), "UKLONILI STE PRIORITY", Toast.LENGTH_LONG).show();
                        }
                    })
                    .show();

        });
    }
}