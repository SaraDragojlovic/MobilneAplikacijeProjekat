package raf.rs.prviprojekatmobilne.listRecycler;

import android.annotation.SuppressLint;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;

import raf.rs.prviprojekatmobilne.model.DanObaveza;

public class ListDiffItemCallBack extends DiffUtil.ItemCallback<DanObaveza>{

    @Override
    public boolean areItemsTheSame(@NonNull DanObaveza oldItem, @NonNull DanObaveza newItem) {
        return oldItem.getStartTime() == newItem.getStartTime();
    }

    @SuppressLint("DiffUtilEquals")
    @Override
    public boolean areContentsTheSame(@NonNull DanObaveza oldItem, @NonNull DanObaveza newItem) {
        return  (oldItem.getDanPrioritet() == newItem.getDanPrioritet()) &&
                (oldItem.getObaveze() == newItem.getObaveze()) &&
                (oldItem.getOpisObaveze() == newItem.getOpisObaveze());
    }
}