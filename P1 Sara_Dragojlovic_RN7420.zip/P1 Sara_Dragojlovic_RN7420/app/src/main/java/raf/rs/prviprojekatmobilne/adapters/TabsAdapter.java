package raf.rs.prviprojekatmobilne.adapters;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

import raf.rs.prviprojekatmobilne.fragments.AllPriorityFragment;
import raf.rs.prviprojekatmobilne.fragments.HighPriorityFragment;
import raf.rs.prviprojekatmobilne.fragments.LowPriorityFragment;
import raf.rs.prviprojekatmobilne.fragments.MidPriorityFragment;
import raf.rs.prviprojekatmobilne.fragments.ProfileFragment;

public class TabsAdapter extends FragmentPagerAdapter {

    public static final int LOW_TAB = 0;
    public static final int MID_TAB = 1;
    public static final int HIGH_TAB = 2;
    public static final int ALL_TAB = 3;

    public static final int TABS_COUNT = 4;

    private Fragment lowFragment = null;
    private Fragment midFragment = null;
    private Fragment highFragment = null;




    public TabsAdapter(@NonNull FragmentManager fm) {
        super(fm, BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT);
    }

    @NonNull
    @Override
    public Fragment getItem(int position) {
        switch (position){
            case 0: return lowFragment =  new LowPriorityFragment();
            case 1: return midFragment = new MidPriorityFragment();
            case 2: return highFragment = new HighPriorityFragment();
            default: return new AllPriorityFragment();
        }
    }



    @Override
    public int getCount() {
        return TABS_COUNT;
    }

    @Nullable
    @Override
    public CharSequence getPageTitle(int position) {
        switch (position) {
            case 0: return "LOW";
            case 1: return "MID";
            case 2: return "HIGH";
            default: return "ALL";
        }
    }

    public Fragment getFragments(int position){
        switch (position){
            case 0: return  lowFragment;
            case 1: return midFragment;
            case 2: return highFragment;

        }
        return null;
    }
}
