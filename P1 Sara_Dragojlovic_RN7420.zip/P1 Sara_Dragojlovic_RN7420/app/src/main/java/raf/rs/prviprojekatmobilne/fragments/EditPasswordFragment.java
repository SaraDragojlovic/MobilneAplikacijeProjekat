package raf.rs.prviprojekatmobilne.fragments;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import raf.rs.prviprojekatmobilne.R;


public class EditPasswordFragment extends Fragment {

    private EditText editPassword;
    private Button changeButton;

    public EditPasswordFragment(){
        super(R.layout.fragment_edit_password);
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        init(view);
    }

    private void init(View view){
        initView(view);
        initListeners();
    }

    private void initView(View view) {
        editPassword = view.findViewById(R.id.editPasswordText);
        changeButton = view.findViewById(R.id.buttonChangePass);

    }

    private void initListeners(){

    }
}